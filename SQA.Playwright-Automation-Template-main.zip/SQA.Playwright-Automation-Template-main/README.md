# Playwright Template
The objective of this project is to bring uniformity across the playwright projects in casino. In this document we are going to explain how to use the playwright template for setting up a new project. 

#	Installation
  The following software need to install before setup any new project.
1.	Visual Studio Code with the plugin “Playwright Test for VScode”
2.	NodeJS (latest version)

# New project setup using template:

1.	Create a folder with the project name for eg. “DemoProject
   
       ![Step1](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step1.png)

2.	Download this template as zip folder

       ![Step2](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step2.png)   
3.	Extract the folder, except docs folder copy all the folders and files and paste it under your project folder

       ![Step3](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step3.png) 
4.	Open Visual Studio Code. From menu click File->Open Folder..-> Select your project folder

       ![Step4](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step4.png) 
5.	Once your project folder loaded, open “package.json” and change the project name from “Playwright-Template” to your project name

       ![Step5](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step5.png) 
6.	Open Command Palette in vsc by pressing Ctrl+Shift+p and select Create New Terminal -> that will bring you the terminal.

       ![Step6](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step6.png) 
7.	From Terminal type “npm run setup”, this will install all the dependencies.( Please note that If we are behind the firewall, we need to connect to IGT VPN and run this command.)

       ![Step7](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step7.png) 

# Folder Structure:
The template comes with the four folders, tests, utils, test-setup and custom-reporters.
    
### tests:
Under “tests” folder user can see three folders naming “pages”, “specs” and “testdata”. The pages folder contains all the page classes, specs folder contains all the playwright tests and testdata folder contains test data Json file. 

  ![Step8](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step8.png) 
### test-setup:
Under “test-setup” folder we have global setup and global teardown file. We can use this file in future if required.

  ![Step9](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step9.png) 
### utils:
Under “utils” folder we have playwright utility and common utility files

  ![Step10](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step10.png) 
    
### custom-reporters:
Under this folder we have dashboard reporter

  ![Step11](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step11.png) 
# .env
From here user can control the environment name, base URL, assertion time out, action timeout and navigation timeout

   ![Step12](https://github.com/igt-casino/Automation.Playwright-Template/blob/main/docs/images/Step12.png) 
# Test Execution and Report
 1. From terminal execute the command “npm run test”, this will open a chrome browser and execute all the tests.
 2. From terminal execute the command “npm run test:headless”, this will open a chrome browser with headless mode and execute all the test
 3. After the execution user can execute “npm run report” to show the html report.
