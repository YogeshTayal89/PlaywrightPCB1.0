import { Locator, Page, expect } from "@playwright/test";
import PlaywrightUtil from "../../utils/playwright-utils";


export default class DashboardPage {
    
    //library objects declaration
    page: Page;
    util: PlaywrightUtil;

    //dashboard locators
    profileicon: Locator; profilelogout: Locator; menu: Locator; navappl: Locator;
    rwefs: Locator; rwefsheader: Locator;
    leftmenu: Locator; rwefsleftmenu: Locator;

    constructor(browserpage: Page) {
        this.page = browserpage;
        this.util = new PlaywrightUtil();

        this.profileicon = this.page.locator('//*[@id="user-avatar"]')
        this.profilelogout = this.page.locator('a').filter({ hasText: 'Logout' });
        this.rwefs = this.page.locator('//h3[text()="RW-EFS"]');
        this.rwefsheader = this.page.frameLocator('#iframe-RW-EFS').getByText('RW-EFS');
        this.leftmenu = this.page.locator("//i[text()='apps']");
        this.rwefsleftmenu = this.page.locator("//*[@id='app']/div[5]/descendant::div[text()='RW-EFS']");

    }

    /**
     * This method is used to verify whether the dashbaord page is present or not
     */
    async isDashboardPresent() {
        await expect(this.profileicon).toBeVisible();
    }

    /**
     * This method is used to do the log out from application
     */
    async logout() {
        await this.util.clickElement(this.profileicon);
        await this.util.clickElement(this.profilelogout);
    }

    /**
     * This method is used to verify the application navigation from application dashboard
     */
    async verifyApplNavFromDashboard() {
        await this.util.clickElement(this.rwefs);
        await this.verifyEfsApplicationPage();

    }

    /**
     * This method is used to verify the application navigation from left hand side menu
     */

    async verifyApplNavFromLeftMenu() {
        await this.util.clickElement(this.leftmenu);
        await this.util.clickElement(this.rwefsleftmenu);
        await this.verifyEfsApplicationPage();

    }

    /**
     * This method is used to verify the rwefs applicaion is opened or not
     */
    async verifyEfsApplicationPage() {
        await this.util.verifyElementPresent(this.rwefsheader);
    }

}