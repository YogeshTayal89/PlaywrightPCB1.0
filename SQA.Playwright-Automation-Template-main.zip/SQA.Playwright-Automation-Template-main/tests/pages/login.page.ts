import {Locator, Page, expect} from "@playwright/test"
import PlaywrightUtil from "../../utils/playwright-utils";


export default class Loginpage {

   //library objects declaration
   page: Page;
   util: PlaywrightUtil;

   //Locators
   sitedropdown: Locator; optionmaster: Locator; usernamefield: Locator; passwordfield: Locator; loginbtn: Locator;
   errortitle: Locator; errormessage: Locator; okbtn: Locator;

   username1:Locator;

   constructor(browserpage: Page) {
      this.page = browserpage
      this.util = new PlaywrightUtil();

      this.sitedropdown = this.page.getByLabel('Site');
      this.optionmaster = this.page.locator('a').filter({ hasText: 'Master' });
      this.usernamefield = this.page.getByLabel('User ID');
      this.passwordfield = this.page.getByLabel('Password');
      this.loginbtn = this.page.getByRole('button', { name: 'Login' });
      this.errortitle = this.page.locator('//*[@id="app"]/div[2]/div/div/div[text()="Error"]');
      this.errormessage = this.page.locator('//*[@id="app"]/div[2]/div/div/div[@class="v-card__text"]');
      this.okbtn = this.page.getByRole('button', { name: 'OK' });

      this.username1=this.page.getByLabel('User ID')

   }

   /**
    * This mehtod is used to navigate to portal
    * @param url 
    */
   async doNavigateToPortal(url: string) {
      await this.util.openURL(this.page, url);
   }

   /**
    * This method is used to login to the application
    * @param username 
    * @param password 
    */
   async doLogin(username: string, password: string) {
      await this.util.clickElement(this.sitedropdown);
      await this.util.clickElement(this.optionmaster);
      await this.util.typeText(this.usernamefield, username);
      await this.util.typeText(this.passwordfield, password);
      await this.util.clickElement(this.loginbtn);
   }

   /**
    * This method is used to verify the login page is present or not
    */
   async isLoginPagePresent() {
      await this.util.verifyElementPresent(this.usernamefield);
   }


   /**
    * This method is used to verify the error message on providing invalid credentials
    * @param expectedmsg 
    */
   async verifyErrorMessage(expectedmsg: string) {
      await this.util.verifyElementPresent(this.errortitle);
      await this.util.verifyElementPresent(this.errormessage);
      await this.util.verifyTextPresent(this.errormessage, expectedmsg);

   }

}