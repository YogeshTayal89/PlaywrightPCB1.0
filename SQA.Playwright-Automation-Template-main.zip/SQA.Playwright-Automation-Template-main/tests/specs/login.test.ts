import {test } from "@playwright/test";
import Loginpage from "../pages/login.page";
import DashboardPage from "../pages/dashboard.page";
import * as invalidcredentials from "../testdata/InvalidCredentials.json"
import DBUtils from "../../utils/db-utils";
const testdata = require(`../testdata/${String(process.env.ENVIRONMENT)}.json`);

let username: any;
let password: any;

test.describe('Login suite', () => {

    test.beforeAll(async () => {
      //reading credentials test data from ${environment}.json file
       username = testdata.credentials.testdata[0].username;
       password = testdata.credentials.testdata[0].password;
      

    });

    test.beforeEach(async ({ page }) => {
        await test.step("Given I am on the login screen", async () => {
        const loginpage = new Loginpage(page);
        await loginpage.doNavigateToPortal("/")
        });
    });


    test('Scenario Outline: As a user , I can login to the application @Smoke @Login @demo', async ({ page }) => {
        await test.step(`When I can login to the application using '${username}' and '${password}'`, async () => {
            const loginpage = new Loginpage(page);
            await loginpage.doLogin(username, password);
        });
        await test.step('Then I should see dashboard screen', async () => {
            const dashboardpage = new DashboardPage(page);
            await dashboardpage.isDashboardPresent();
        });

    });

    test('Scenario Outline: As a user , I can login and logout from the application @Smoke @Login @demo', async ({ page }) => {
        const loginpage = new Loginpage(page);
        await test.step(`When I can login to the application using '${username}' and '${password}'`, async () => {
            await loginpage.doLogin(username, password);
        });
        const dashboardpage = new DashboardPage(page);
        await test.step('Then I should see dashboard screen', async () => {
            await dashboardpage.isDashboardPresent();
        });
        await test.step('Given Do logout from dashboard screen ', async () => {
            await dashboardpage.logout();
        });
        await test.step('I should see login screen', async () => {
            await loginpage.isLoginPagePresent();
        });

    });

    let i = 0;
    invalidcredentials.credentials.forEach(data => {

        test(`Scenario Outline: As a invalid user , while login I can see the error message for ${data.scenario} @Smoke @Login @demo`, async ({ page }) => {

            const loginpage = new Loginpage(page);
            await test.step(`When I can login with invalid credentials '${data.username}' and '${data.password}'`, async () => {
                await loginpage.doLogin(data.username, data.password);
            });
            await test.step(`Then I should see error message ${data.message}`, async () => {
                await loginpage.verifyErrorMessage(data.message);

            });
            i++;
        }); //End of test
    });// End of For loop

    /**
     * Sample teset for DB connectivity
     */
    test('Scenario Outline: As a user , I can conenct the db and execute query @Smoke @Login @demo', async ({ page }) => {
        
        await test.step(`I can connec to the db`, async () => {
            //the below db urlis the dummy one. For demo purpose created
            let dburl:string="Server=1.2.3.4,1433;Database=sampledb;User Id=sampleuserid;Password=samplepassword;Encrypt=false;trustServerCertificate=true;useUTC=false";
            const dbutil = new DBUtils(dburl);
            //for select query, it will return the resultset
            let result:any=await dbutil.getResultSet("sample select quesry need to pass here")

            //for delete or update query , it will return the number of rows affected
            let resultforupdate = await dbutil.doUpdateOrDelete("delete or update query need to be passed")
        });

    });

});
