async function globalSetup() {
    
      console.log('Before All');
  }
  
  export default globalSetup;
  