async function globalTeardown() {
    
      console.log('After all');
  }
  
  export default globalTeardown;
  